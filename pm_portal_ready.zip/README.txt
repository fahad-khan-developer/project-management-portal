Project Management Portal — Ready-to-run bundle

Run:
1) npm install
2) npm start
Open http://localhost:3000

This is a simple starter. For production add auth, HTTPS, backups.